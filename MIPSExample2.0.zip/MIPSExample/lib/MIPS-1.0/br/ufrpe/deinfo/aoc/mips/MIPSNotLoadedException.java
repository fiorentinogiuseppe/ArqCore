/*
 * Universidade Federal Rural de Pernambuco - ufrpe.br
 * Departamento de Estat�stica e Inform�tica - deinfo.ufrpe.br
 * Disciplina de Arquitetura e Organiza��o de Computadores - deinfo.ufrpe.br/14064
 * Professor Andr� Aziz - andreaziz@deinfo.ufrpe.br
 * 
 * Esse programa foi criado com objetivos acad�micos, sendo vedada a sua venda. N�o h�
 * garantias de uso e funcionamento.
 * 
 * Arquivo: MIPSNotLoadedException.java
 * Licen�a: GPL v3
 */
package br.ufrpe.deinfo.aoc.mips;

/**
 * Exce��o levantada quando o usu�rio tentou executar a simula��o sem indicar
 * qual � a implementa��o da interface MIPS ser� executada.
 * 
 * @author Aziz
 * @since 1.0
 * @version 1.0
 */
public class MIPSNotLoadedException extends Exception {

	private static final long serialVersionUID = -2038950333772138603L;

	public MIPSNotLoadedException() {
	}

	public MIPSNotLoadedException(String arg0) {
		super(arg0);
	}

	public MIPSNotLoadedException(Throwable arg0) {
		super(arg0);
	}

	public MIPSNotLoadedException(String arg0, Throwable arg1) {
		super(arg0, arg1);
	}

	public MIPSNotLoadedException(String arg0, Throwable arg1, boolean arg2,
			boolean arg3) {
		super(arg0, arg1, arg2, arg3);
	}

}
