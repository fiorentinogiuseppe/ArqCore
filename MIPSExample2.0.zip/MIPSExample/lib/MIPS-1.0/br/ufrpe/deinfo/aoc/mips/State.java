/*
 * Universidade Federal Rural de Pernambuco - ufrpe.br
 * Departamento de Estat�stica e Inform�tica - deinfo.ufrpe.br
 * Disciplina de Arquitetura e Organiza��o de Computadores - deinfo.ufrpe.br/14064
 * Professor Andr� Aziz - andreaziz@deinfo.ufrpe.br
 * 
 * Esse programa foi criado com objetivos acad�micos, sendo vedada a sua venda. N�o h�
 * garantias de uso e funcionamento.
 * 
 * Arquivo: State.java
 * Licen�a: GPL v3
 */
package br.ufrpe.deinfo.aoc.mips;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * Armazena as informa��es de estado do MIPS, como os registradores e mem�ria. 
 * Controla o acesso aos registradores de prop�sito geral e os de controle, bem
 * como o acesso � mem�ria de dados e instru��es.
 * 
 * @author Aziz
 * @since 1.0
 * @version 1.0
 */
public class State {
	
	/**
	 * Registradores existentes no MIPS.
	 *  
	 * @author Aziz
	 * @since 1.0
	 * @version 1.0
	 */
	public enum Register {
		zero,
		at,
		v0, v1,
		a0, a1, a2, a3,
		t0, t1, t2, t3, t4, t5, t6, t7,
		s0, s1, s2, s3, s4, s5, s6, s7,
		t8, t9,
		k0, k1,
		gp,	sp, fp, ra,
		pc
	}
	
	/**
	 * N�mero de registradores de prop�sito geral.
	 */
	public static final Integer REGISTER_NUMBER = 32;
	
	/**
	 * Tamanho m�ximo que as mem�rias podem ter na simula��o.
	 */
	public static final Integer MEMORY_SIZE = Integer.MAX_VALUE;
		
	/**
	 * Registrador Program Counter. Armazena o endere�o da pr�xima instru��o 
	 * que ser� executada.
	 */
	private Integer PC;
	
	/**
	 * Banco de registradores de prop�sito geral.
	 */
	private Integer[] registerBank;
	
	/**
	 * Mem�ria de instru��es.
	 */
	private Map<Integer, Integer> instructionMemory;
	
	/**
	 * Mem�ria de dados.
	 */
	private Map<Integer, Integer> dataMemory;
	
	/**
	 * Indica se a simula��o deve ser interrompida. Inicia em falso.
	 */
	private Boolean halt;
	
	/**
	 * Lista de arquivos carregados na mem�ria de dados. Em caso de reset, 
	 * esses arquivos ser�o recarregados automaticamente. 
	 */
	private Map<Path, Integer> dataFiles;
	
	/**
	 * Lista de arquivos carregados na mem�ria de instru��es. Em caso de reset, 
	 * esses arquivos ser�o recarregados automaticamente.
	 */
	private Map<Path, Integer> instructionFiles;
	
	/**
	 * Endere�o inicial do Program Counter. Valor padr�o � zero.
	 */
	private Integer startPC;
	
	/**
	 * Construtor padr�o da classe. Inicializa todos os par�metros com zero e
	 * executa a rotina de reset.
	 * 
	 * @throws IOException	Em caso de falha no acesso aos arquivos de dados ou
	 * 						instru��es.
	 */
	public State() throws IOException {
		this.instructionMemory = new HashMap<Integer, Integer>();
		this.dataMemory = new HashMap<Integer, Integer>();
		this.dataFiles = new HashMap<Path, Integer>();
		this.instructionFiles = new HashMap<Path, Integer>(); 
		this.startPC = 0;
		
		this.reset();
	}
	
	/**
	 * Retorna o valor armazenado no registrador Program Counter.
	 * 
	 * @return O valor armazenado no PC.
	 */
	public Integer getPC() {
		return this.PC;
	}

	/**
	 * Altera o valor armazenado no registrador Program Counter.
	 *  
	 * @param PC	O novo valor do PC.
	 */
	public void setPC(Integer PC) {
		this.PC = PC;
	}
	
	/**
	 * Indica se simula��o est� interrompida.
	 * 
	 * @return	true - Se est� interrompida.
	 * 			false - Caso contr�rio.
	 */
	public Boolean isHalted() {
		return halt;
	}

	/**
	 * Interrompe a simula��o. A simula��o s� ser� retomada se for executada a
	 * rotina de reset.
	 */
	public void halt() {
		this.halt = true;
	}

	/**
	 * Apaga a lista de arquivos de dados.
	 */
	public void clearDataFiles() {
		this.dataFiles.clear();
	}
	
	/**
	 * Apaga a lista de arquivos de instru��es.
	 */
	public void clearInstructionFiles() {
		this.instructionFiles.clear();
	}
	
	/**
	 * Reinicia a simula��o ao estado inicial. Todas as vari�veis s�o zeradas e
	 * os arquivos de dados e instru��es s�o recarregados. O PC � carregado com
	 * o seu valor inicial.
	 * 
	 * @throws IOException	Em caso de falha no acesso aos arquivos de dados ou
	 * 						instru��es.
	 */
	public void reset() throws IOException {
		// Reinicia o PC.
		this.PC = this.startPC;
		
		// Zera os registradores internos.
		this.registerBank = new Integer[REGISTER_NUMBER];
		this.halt = false;
		this.dataMemory.clear();
		this.instructionMemory.clear();
				
		// Recarrega os arquivos de dados.
		Set<Map.Entry<Path, Integer>> dataSet = this.dataFiles.entrySet();
		for (Map.Entry<Path, Integer> entry : dataSet) {
			this.loadDataMemory(entry.getKey(), entry.getValue());
		}
		
		// Recarrega os arquivos de instru��es.
		Set<Map.Entry<Path, Integer>> instructionSet = this.dataFiles.entrySet();
		for (Map.Entry<Path, Integer> entry : instructionSet) {
			this.loadDataMemory(entry.getKey(), entry.getValue());
		}
		
		// Zera os registradores de prop�sito geral.
		for (int i = 0; i < registerBank.length; i++) {
			this.registerBank[i] = 0;
		}
	}
	
	/**
	 * Retorna o valor armazenado em registrador de prop�sito geral.
	 * 
	 * @param address	O endere�o do registrador (0 a 31).
	 * @return			O conte�do do registrador.
	 */
	public Integer readRegister(Integer address) {		
		return this.registerBank[address];
	}
	
	/**
	 * Altera o valor do registrador de prop�sito geral.
	 * 
	 * @param address	O endere�o do registrador (0 a 31).
	 * @param data		O novo conte�do do registrador.
	 */
	public void writeRegister(Integer address, Integer data) {
		// Registrador zero nunca � alterado.
		if (address == 0)
			return;
		
		this.registerBank[address] = data;
	}
	
	/**
	 * Retorna uma instru��o da mem�ria de instru��es.
	 * 
	 * @param address	Endere�o da instru��o.
	 * @return			A instru��o.
	 * 
	 * @throws InvalidMemoryAlignmentExpcetion	Se o endere�o n�o estiver 
	 * 											alinhado (m�ltiplo de 4).
	 */
	public Integer readInstructionMemory(Integer address) throws InvalidMemoryAlignmentExpcetion {
		// Verifica se o acesso est� alinhado.
		if (address % 4 != 0) {
			throw new InvalidMemoryAlignmentExpcetion("Memory address " + address + " is not alligned!");
		}

		if (this.instructionMemory.containsKey(address)) {
			return this.instructionMemory.get(address);
		} else {
			return 0;
		}
	}
		
	/**
	 * Retorna uma palavra da mem�ria de dados.
	 * 
	 * @param address	Endere�o do dado.
	 * @return			O dado.
	 */
	public Integer readWordDataMemory(Integer address) {
		Integer ret = 0;
		for (Integer i = 0; i < 4; i++){
			if (this.dataMemory.containsKey(address + i)) {
				ret |= ((this.dataMemory.get(address + i) & 0x0FF) << (8 * i));								
			} 
		}		
		return ret;
	}

	/**
	 * Escreve um byte na mem�ria de dados.
	 * 
	 * @param address	Endere�o do byte.
	 * @param _byte		O novo byte.
	 */
	public void writeByteDataMemory(Integer address, Integer _byte) {	
		this.dataMemory.put(address, (_byte & 0x0FF));
	}

	/**
	 * Escreve meia palavra na mem�ria de dados.
	 * 
	 * @param address	Endere�o da meia palavra.
	 * @param half		A nova meia palavra.
	 */
	public void writeHalfwordDataMemory(Integer address, Integer half) {
		for (Integer i = 0; i < 2; i++) {
			this.writeByteDataMemory(address + i, half >> (8 * i));
		}
	}
	
	/**
	 * Escreve uma palavra na mem�ria de dados.
	 * 
	 * @param address	Endere�o da palavra.
	 * @param word		A nova palavra.
	 */
	public void writeWordDataMemory(Integer address, Integer word) {
		for (Integer i = 0; i < 4; i++) {
			this.writeByteDataMemory(address + i, word >> (8 * i));
		}
	}

	/**
	 * Carrega um arquivo na mem�ria de instru��es.
	 * 
	 * @param instructionFile	O caminho para o arquivo.
	 * @param startAddress		A posi��o inicial onde o arquivo ser� c
	 * 							arregado.
	 * @return					O n�mero de instru��es carregadas.
	 * 
	 * @throws IOException		Em caso de falha no acesso ao arquivo.
	 */
	public Integer loadInstructionMemory(Path instructionFile, Integer startAddress) throws IOException {
		// Carrega todas as instru��es do arquivo.
		List<String> lines = Files.readAllLines(instructionFile);
		Integer counter = 0;
		
		// Armazena cada instru��o carregada na mem�ria.
		for (String line : lines) {
			Integer instruction = Integer.parseInt(line, 16);
			this.instructionMemory.put(startAddress + (counter << 2), instruction);
			counter++;
		}
		
		return counter;
	}
	
	/**
	 * Carrega um arquivo na mem�ria de dados.
	 * 
	 * @param dataFile		O caminho para o arquivo.
	 * @param startAddress	A posi��o inicial onde o arquivo ser� c
	 * 						arregado.
	 * @return				O n�mero de dados carregados.
	 * 
	 * @throws IOException	Em caso de falha no acesso ao arquivo.
	 */
	public Integer loadDataMemory(Path dataFile, Integer startAddress) throws IOException {
		// Carrega todos os dados do arquivo.
		List<String> lines = Files.readAllLines(dataFile);
		Integer counter = 0;
		
		// Armazena cada dado carregado na mem�ria.
		for (String line : lines) {
			Integer instruction = Integer.parseInt(line, 16);
			for (Integer i = 0; i < 4; i++) {
				this.dataMemory.put(startAddress + (counter << 2) + i, (instruction >> (8 * i)) & 0x0FF);
			}			
			counter++;
		}
		
		return counter;
	}
	
	/**
	 * Faz um dump da mem�ria de dados indicada no array de destino. N�o h� 
	 * overlap de endere�os.
	 * 
	 * @param startAddress	A posi��o de mem�ria inicial do dump.
	 * @param dest			O array de destino. Os dados ser�o carregados a 
	 * 						partir da posi��o zero do array. 
	 * @return				Retorna o n�mero de dados exportados.
	 */
	public Integer dumpDataMemory(Integer startAddress, final Integer[] dest) {
		Integer i, j, k;
		
		// Executa o dump...
		for(i = 0, k = 0; i < dest.length && startAddress + k < MEMORY_SIZE; i++, k += 4) {
			
			// Reset user data.
			dest[i] = 0;
			
			// Read 4 bytes from memory
			for (j = 0; j < 4; j++) {
				// Verifica se o endere�o est� na mem�ria e o exporta.
				if (this.dataMemory.containsKey(startAddress + k + j)) {
					dest[i] |= (this.dataMemory.get(startAddress + k) << (8 * j));
				} 

			}			
		}
		
		return i;
	}
	
	/**
	 * Faz um dump da mem�ria de instru��es indicada no array de destino. N�o 
	 * h� overlap de endere�os.
	 * 
	 * @param startAddress	A posi��o de mem�ria inicial do dump.
	 * @param dest			O array de destino. Os dados ser�o carregados a 
	 * 						partir da posi��o zero do array. 
	 * @return				Retorna o n�mero de dados exportados.
	 */
	public Integer dumpInstructionMemory(Integer startAddress, final Integer[] dest) {
		Integer i, k;
		
		// Executa o dump...
		for(i = 0, k = 0; i < dest.length && startAddress + k < MEMORY_SIZE; i++, k += 4) {
			
			// Verifica se o endere�o est� na mem�ria e o exporta.
			if (this.instructionMemory.containsKey(startAddress + k)) {
				dest[i] = this.instructionMemory.get(startAddress + k);
			} 
			// Caso contr�rio informa que o conte�do � zero. Isso evita 
			// preencher a mem�ria com dados zero desnecess�rios. 
			else {
				dest[i] = 0;
			}
		}
		
		return i;
	}

	
	/**
	 * Faz um dump dos registradores de prop�sito geral no array destino. O 
	 * array deve ter o mesmo tamanho que o n�mero total de registradores de 
	 * prop�sito geral.
	 * @param dest
	 */
	public void dumpRegister(final Integer[] dest) {
		// Verifica se o tamanho do registrador est� correto.
		if (dest.length == REGISTER_NUMBER) {
			
			// Exporta todos os registrador no array destino.
			for (int i = 0; i < REGISTER_NUMBER; i++) {
				dest[i] = this.registerBank[i];
			}
		}
	}

}
