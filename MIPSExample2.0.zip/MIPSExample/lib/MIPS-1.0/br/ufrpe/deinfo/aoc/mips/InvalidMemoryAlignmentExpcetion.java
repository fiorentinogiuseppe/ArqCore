/*
 * Universidade Federal Rural de Pernambuco - ufrpe.br
 * Departamento de Estat�stica e Inform�tica - deinfo.ufrpe.br
 * Disciplina de Arquitetura e Organiza��o de Computadores - deinfo.ufrpe.br/14064
 * Professor Andr� Aziz - andreaziz@deinfo.ufrpe.br
 * 
 * Esse programa foi criado com objetivos acad�micos, sendo vedada a sua venda. N�o h�
 * garantias de uso e funcionamento.
 * 
 * Arquivo: InvalidMemoryAlignmentException.java
 * Licen�a: GPL v3
 */
package br.ufrpe.deinfo.aoc.mips;

/**
 * Exce��o levantada quando o usu�rio tentou acessar a mem�ri com endere�o que
 * n�o � alinhado (n�o � m�ltiplo de 4).
 * 
 * @author Aziz
 * @since 1.0
 * @version 1.0
 */
public class InvalidMemoryAlignmentExpcetion extends Exception {

	private static final long serialVersionUID = 480446531287188856L;

	public InvalidMemoryAlignmentExpcetion() {
	}

	public InvalidMemoryAlignmentExpcetion(String message) {
		super(message);
	}

	public InvalidMemoryAlignmentExpcetion(Throwable cause) {
		super(cause);
	}

	public InvalidMemoryAlignmentExpcetion(String message, Throwable cause) {
		super(message, cause);
	}

	public InvalidMemoryAlignmentExpcetion(String message, Throwable cause,
			boolean enableSuppression, boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
	}

}
