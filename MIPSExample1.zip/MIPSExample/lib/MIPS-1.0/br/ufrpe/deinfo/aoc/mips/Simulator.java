/*
 * Universidade Federal Rural de Pernambuco - ufrpe.br
 * Departamento de Estat�stica e Inform�tica - deinfo.ufrpe.br
 * Disciplina de Arquitetura e Organiza��o de Computadores - deinfo.ufrpe.br/14064
 * Professor Andr� Aziz - andreaziz@deinfo.ufrpe.br
 * 
 * Esse programa foi criado com objetivos acad�micos, sendo vedada a sua venda. N�o h�
 * garantias de uso e funcionamento.
 * 
 * Arquivo: Simulator.java
 * Licen�a: GPL v3
 */
package br.ufrpe.deinfo.aoc.mips;

import java.io.File;
import java.io.IOException;
import java.nio.file.NoSuchFileException;
import java.nio.file.Path;
import java.util.Arrays;
import java.util.List;

import jline.console.ConsoleReader;
import jline.console.completer.AggregateCompleter;
import jline.console.completer.ArgumentCompleter;
import jline.console.completer.EnumCompleter;
import jline.console.completer.FileNameCompleter;
import jline.console.completer.NullCompleter;
import jline.console.completer.StringsCompleter;
import jline.console.history.FileHistory;
import br.ufrpe.deinfo.jline.IntegerCompleter;
import br.ufrpe.deinfo.jline.TreeCompleter;

/**
 * Gerencia a simula��o e console do usu�rio. N�o � poss�vel construir um 
 * objeto desta classe. Para utiliz�-la � necess�rio usar os m�todos est�ticos.
 * 
 * @author Aziz
 * @since 1.0
 * @version 1.0
 */
public class Simulator {
	
	/**
	 * N�vel do log que ser� apresentado ao usu�rio. 
	 * <br>
	 * INFO - Apresenta apenas mensagens de avisos do usu�rio.<br>
	 * ERROR - Apresenta mensagens de erros internos do simulador.<br>
	 * DEBUG - Apresenta detalhes de exce��es internas.
	 * 
	 * @author Aziz
	 * @since 1.0
	 * @version 1.0
	 */
	public enum LogLevel {
		INFO, ERROR, DEBUG
	}

	/**
	 * Inst�ncia �nica do simulador.
	 */
	private static Simulator INSTANCE;

	/**
	 * N�vel do log. Padr�o � ERROR.
	 */
	private LogLevel logLevel;
	
	/**
	 * Console (terminal) do usu�rio.
	 */
	private ConsoleReader console;
	
	/**
	 * Estado corrente da simula��o MIPS.
	 */
	private State state;
	
	/**
	 * MIPS implementado pelo usu�rio.
	 */
	private MIPS mips;
	
	/**
	 * N�mero de ciclos executado.
	 */
	private Integer cycles;

	/**
	 * Construtor padr�o e privado da classe.
	 * 
	 * @throws IOException	Caso n�o seja poss�vel inicializar o terminal.
	 */
	private Simulator() 
			throws IOException {
		this.mips = null;
		this.state = new State();
		this.console = new ConsoleReader();
		this.logLevel = LogLevel.ERROR;

		this.reset();
	}

	/**
	 * Retorna a inst�ncia �nica do simulador.
	 * 
	 * @return	A inst�ncia.
	 * 
	 * @throws IOException	Caso n�o seja poss�vel inicializar o terminal.
	 */
	private static Simulator getInstance() 
			throws IOException {
		if (INSTANCE == null) {
			INSTANCE = new Simulator();
		}

		return INSTANCE;
	}
	
	/**
	 * Imprime mensagens de log no n�vel INFO.
	 * 
	 * @param s	Mensagens.
	 * 
	 * @throws IOException	Caso haja falhas no terminal.
	 */
	public static void info(String... s) throws IOException {
		log(LogLevel.INFO, s);
	}

	/**
	 * Imprime mensagens de log no n�vel ERROR.
	 * 
	 * @param s	Mensagens.
	 * 
	 * @throws IOException	Caso haja falhas no terminal.
	 */
	public static void error(String... s) throws IOException {
		log(LogLevel.ERROR, s);
	}
	
	/**
	 * Imprime mensagens de log no n�vel DEBUG.
	 * 
	 * @param ex	Exe��o que ser� detalhada com printStackTrace.
	 * @param s		Mensagens.
	 * 
	 * @throws IOException	Caso haja falhas no terminal.
	 */
	public static void debug(Exception ex, String... s) throws IOException {
		debug(s);
		if (getInstance().logLevel == LogLevel.DEBUG)
			ex.printStackTrace();
	}
	
	/**
	 * Imprime mensagens de log no n�vel DEBUG.
	 * 
	 * @param s		Mensagens.
	 * 
	 * @throws IOException	Caso haja falhas no terminal.
	 */
	public static void debug(String... s) throws IOException {
		log(LogLevel.DEBUG, s);		
	}
	
	/**
	 * M�todo global de log que verifica se o n�vel solicitado � o mesmo
	 * configurado.
	 * 
	 * @param level	O n�vel do log
	 * @param s		Mensagem
	 * 
	 * @throws IOException	Caso haja falhas no terminal.
	 */
	private static void log(LogLevel level, String... s) throws IOException {
		if (getInstance().logLevel.ordinal() < level.ordinal())
			return;
		
		List<String> strings = Arrays.asList(s);
		
		getConsole().print("[" + level + "] ");
		for (String string : strings) {
			getConsole().print(string);
		}
		getConsole().println();
	}

	/**
	 * Altera o n�vel de log do simulador.
	 * 
	 * @param level	Novo n�vel.
	 * 
	 * @throws IOException	Caso haja falhas no terminal.
	 */
	public static void setLogLevel(LogLevel level) throws IOException {
		getInstance().logLevel = level;
	}

	/**
	 * Retorna a inst�ncia �nica do terminal. Mexer nas configura��es desse 
	 * objeto pode provocar o mau funcionamento do simulador.
	 * 
	 * @return	O console
	 * 
	 * @throws IOException	Caso haja falhas no terminal.
	 */
	public static ConsoleReader getConsole() 
			throws IOException {
		return getInstance().console;
	}
	
	/**
	 * Altera a implementa��o do MIPS que ser� simulada.
	 * 
	 * @param mips	O MIPS.
	 * 
	 * @throws IOException	Caso haja falhas no terminal.
	 */
	public static void setMIPS(MIPS mips) 
			throws IOException {
		getInstance().mips = mips;
	}
	
	/**
	 * Inicializa o simulador.
	 * 
	 * @throws IOException	Caso haja falhas no terminal.
	 */
	public static void start() 
			throws IOException {
		getInstance().prompt();
	}
	
	/**
	 * Reinicia o simulador. Essa fun��o s� pode ser acessada pela linha de 
	 * comando do simulador.
	 * 
	 * @throws IOException	Caso haja falhas no terminal.
	 */
	private void reset() 
			throws IOException {
		this.state.reset();
		this.cycles = 0;		
	}

	/**
	 * Carrega um arquivo na mem�ria de instru��es. Essa fun��o s� pode ser 
	 * acessada pela linha de comando do simulador. O arquivo deve estar no 
	 * formato de texto, onde cada linha dever� conter um n�mero em hexadecimal
	 * de 32 bits. Normalmente esse arquivo � exportado do simulador MARS.
	 * 
	 * @param instructionFile	O caminho para o arquivo.
	 * @param startAddress		O endere�o inicial onde o arquivo ser� 
	 * 							carregado.
	 * @return					O n�mero de instru��es carregadas.
	 * 
	 * @throws IOException	Caso haja falhas no terminal ou na abertura do 
	 * 						arquivo.
	 */
	private Integer loadInstructionMemory(Path instructionFile, Integer startAddress) 
			throws IOException {
		return this.state.loadInstructionMemory(instructionFile, startAddress);		
	}

	/**
	 * Carrega um arquivo na mem�ria de dados. Essa fun��o s� pode ser 
	 * acessada pela linha de comando do simulador. O arquivo deve estar no 
	 * formato de texto, onde cada linha dever� conter um n�mero em hexadecimal
	 * de 32 bits. Normalmente esse arquivo � exportado do simulador MARS.
	 * 
	 * @param instructionFile	O caminho para o arquivo.
	 * @param startAddress		O endere�o inicial onde o arquivo ser� 
	 * 							carregado.
	 * @return					O n�mero de dados carregados.
	 * 
	 * @throws IOException	Caso haja falhas no terminal ou na abertura do 
	 * 						arquivo.
	 */
	private Integer loadDataMemory(Path instructionFile, Integer startAddress) 
			throws IOException {
		return this.state.loadDataMemory(instructionFile, startAddress);		
	}

	/**
	 * Executa a simula��o de um ciclo de clock.
	 * 
	 * @throws Exception	V�rias falhas s�o poss�veis.
	 */
	private void cycle() 
			throws Exception {
		if (this.mips == null) {
			throw new MIPSNotLoadedException();
		}

		if (!this.state.isHalted()) {
			this.cycles++;
			this.mips.execute(this.state);
		}
	}

	/**
	 * Executa um certo n�mero de ciclos de clock.
	 * 
	 * @param clockCycles	N�mero de ciclos de clock.
	 * 
	 * @throws Exception	V�rias falhas s�o poss�veis.
	 */
	private void run(Integer clockCycles) 
			throws Exception {
		for (Integer i = 0; i < clockCycles && !this.state.isHalted(); i++) {
			this.cycle();
		}
	}

	/**
	 * Executa um n�mero indeterminado de ciclos de clock at� que o usu�rio
	 * chame o m�todo halt da vari�vel State.
	 * 
	 * @throws Exception	V�rias falhas s�o poss�veis.
	 */
	private void run() 
			throws Exception {
		while(!this.state.isHalted()) {
			this.cycle();
		}
	}

	/**
	 * Inicializa o console de comando do usu�rio. Esse m�todo s� termina
	 * quando o usu�rio digitar o comando 'quit' ou 'exit'.
	 * 
	 * @throws IOException	Caso haja falhas no terminal.
	 */
	private void prompt() 
			throws IOException {
		FileHistory history = null;

		try {
			// Set terminal prompt
			this.console.setPrompt("DEINFO-MIPS> ");
			
			// Load and enable terminal history
			File historyFile = new File(System.getProperty("user.home")+ "/.mips_history");
			history = new FileHistory(historyFile);
			this.console.setHistory(history);
			this.console.setHistoryEnabled(true);

			// Load auto completer terminal commands
			this.console.addCompleter(
				new ArgumentCompleter(
					new AggregateCompleter(
						new TreeCompleter(new StringsCompleter("load", "run", "reset", "dump"))
					),
					new AggregateCompleter(
						new TreeCompleter(new StringsCompleter("data", "instruction"),				"load"),
						new TreeCompleter(new IntegerCompleter("<cycles>"), 						"run"),
						new TreeCompleter(new StringsCompleter("register", "data", "instruction"), 	"dump")
					),
					new AggregateCompleter(	
						new TreeCompleter(new StringsCompleter("memory"), 			"load",	"data"), 							
						new TreeCompleter(new StringsCompleter("memory"), 			"load",	"instruction"),
						new TreeCompleter(new EnumCompleter(State.Register.class),	"dump",	"register"),
						new TreeCompleter(new StringsCompleter("memory"), 			"dump",	"data"),
						new TreeCompleter(new StringsCompleter("memory"), 			"dump",	"instruction")
					),
					new AggregateCompleter(
						new TreeCompleter(new FileNameCompleter(), 						"load", "data",			"memory"),
						new TreeCompleter(new FileNameCompleter(), 						"load", "instruction", 	"memory"),
						new TreeCompleter(new IntegerCompleter("<start_address>", 16),	"dump",	"data",			"memory"),
						new TreeCompleter(new IntegerCompleter("<start_address>", 16),	"dump",	"instruction",	"memory")
					),
					new AggregateCompleter(
						new TreeCompleter(new IntegerCompleter("<start_address>", 16), 		"load", "data", 		"memory", TreeCompleter.ESCAPE), 
						new TreeCompleter(new IntegerCompleter("<start_address>", 16), 		"load", "instruction", 	"memory", TreeCompleter.ESCAPE),
						new TreeCompleter(new IntegerCompleter("<number_of_integers>", 10),	"dump",	"data",			"memory", TreeCompleter.ESCAPE),
						new TreeCompleter(new IntegerCompleter("<number_of_integers>", 10),	"dump",	"instruction",	"memory", TreeCompleter.ESCAPE)
					),
					new NullCompleter()
					)
				);

			// Command line variable
			String line = null;

			// Read a command line forever
			while ((line = console.readLine()) != null) {

				// Check exit condition
				if (line.equalsIgnoreCase("quit") || line.equalsIgnoreCase("exit")) {
					break;
				}

				// Split command line by spaces
				String[] command = line.split(" ");

				// Clear lower case and blank spaces
				for (int i = 0; i < command.length; i++) {
					command[i] = command[i].trim();
				}

				// Decode and call commands
				try {
					if (command.length > 0) {
						if (command[0].equalsIgnoreCase("load")) {
							if (command[1].equalsIgnoreCase("data")) {
								if (command[2].equalsIgnoreCase("memory")) {
									commandLoadDataMemory(command[3], command[4]); continue;							
								}
							} else if (command[1].equalsIgnoreCase("instruction")) {
								if (command[2].equalsIgnoreCase("memory")) {
									commandLoadInstructionMemory(command[3], command[4]); continue;
								}
							} 
						} else if (command[0].equalsIgnoreCase("run")) {
							if (command.length > 1) {
								commandRun(command[1]); continue;
							} else {
								commandRun(); continue;
							}
						} else if (command[0].equalsIgnoreCase("reset")) {
							commandReset(); continue;
						} else if (command[0].equalsIgnoreCase("dump")) {
							if (command[1].equalsIgnoreCase("register")) {
								if (command.length > 2) {
									commandDumpRegister(command[2]); continue;
								} else {
									commandDumpRegister(); continue;
								}
							} else if (command[1].equalsIgnoreCase("data")) {
								if (command[2].equalsIgnoreCase("memory")) {
									commandDumpDataMemory(command[3], command[4]); continue;
								}
							} else if (command[1].equalsIgnoreCase("instruction")) {
								if (command[2].equalsIgnoreCase("memory")) {
									commandDumpInstructionMemory(command[3], command[4]); continue;
								}
							} 
						} 

						throw new CommandNotFoundException();						
					}
				} catch (MIPSNotLoadedException ex) {
					info("MIPS implementation not loaded.");
					debug(ex);
				} catch (ArrayIndexOutOfBoundsException ex) {
					info("Invalid command line! Missing arguments.");
					debug(ex);
				} catch (MemoryOutOfBoundsException ex) {
					info("Memory address is out of bounds.");
					debug(ex);
				} catch (NumberFormatException ex) {
					info(ex.getMessage() + " is not valid integer parameter! Hexadecimal numbers must start with 0x prefix.");
					debug(ex);
				} catch (NoSuchFileException ex) {
					info("File \"" + ex.getMessage() + "\" not found!");
					debug(ex);
				} catch (CommandNotFoundException ex) {
					info("Command not found!");
					debug(ex);
				} catch (Exception ex) {
					info("Unexpected error! Cause: " + ex.getMessage());
					debug(ex);
				}
			}
		} finally {
			if (history != null) {
				history.flush();
			}
		}
	}

	/**
	 * Comando: load data memory filename start_address. Carrega o arquivo na
	 * mem�ria de dados a partir do endere�o inicial indicado.
	 * 
	 * @param filename		Nome do arquivo.
	 * @param startAddress	Endere�o inicial em hexadecimal.
	 * 
	 * @throws NumberFormatException	O endere�o inicial n�o est� em 
	 * 									hexadecimal.
	 * @throws IOException				Caso haja falhas no terminal ou na 
	 * 									abertura do	arquivo.
	 */
	private void commandLoadDataMemory(String filename, String startAddress) throws NumberFormatException, IOException {
		Integer loaded = this.loadDataMemory((new File(filename)).toPath(), Integer.decode(startAddress));
		info("Loaded " + loaded + (loaded > 1 ? " lines" : " line"));
	}

	/**
	 * Comando: load instruction memory filename start_address. Carrega o 
	 * arquivo na mem�ria de dados a partir do endere�o inicial indicado.
	 * 
	 * @param filename		Nome do arquivo.
	 * @param startAddress	Endere�o inicial em hexadecimal.
	 * 
	 * @throws NumberFormatException	O endere�o inicial n�o est� em 
	 * 									hexadecimal.
	 * @throws IOException				Caso haja falhas no terminal ou na 
	 * 									abertura do	arquivo.
	 */
	private void commandLoadInstructionMemory(String filename, String startAddress) throws NumberFormatException, IOException {
		Integer loaded = this.loadInstructionMemory((new File(filename)).toPath(), Integer.decode(startAddress));
		info("Loaded " + loaded + (loaded > 1 ? " lines" : " line"));
	}

	/**
	 * Comando: run cycles. Executa o n�mero de ciclos de clock indicados.
	 * 
	 * @param cycles		N�mero de ciclos de clock.
	 * @throws Exception	V�rias falhas s�o poss�veis.
	 */
	private void commandRun(String cycles) throws Exception {
		this.run(Integer.decode(cycles));
		info("Stopped at cycle " + this.cycles);
	}

	/**
	 * Comando: run. Executa at� a chamada do m�todo halt pelo usu�rio.
	 * 
	 * @throws Exception	V�rias falhas s�o poss�veis.
	 */
	private void commandRun() throws Exception {
		this.run();
		info("Stopped at cycle " + this.cycles);
	}

	/**
	 * Comando: reset. Reinicia o simulador.
	 * 
	 * @throws IOException	Caso haja falhas no terminal ou na abertura do
	 * 						arquivo.
	 */
	private void commandReset() throws IOException  {
		this.reset();
		info("Reset");
	}

	/**
	 * Comando: dum register registername. Imprime o conte�do do registrador 
	 * indicado.
	 * 
	 * @param register	O nome do registrador.
	 * 
	 * @throws IOException	Caso haja falhas no terminal.
	 */
	private void commandDumpRegister(String register) throws IOException  {
		Integer[] registers = new Integer[State.REGISTER_NUMBER];
		this.state.dumpRegister(registers);
		State.Register reg = State.Register.valueOf(register);

		if (reg == State.Register.pc) {
			info(String.format("PC = %08x", this.state.getPC()));
		} else {
			Integer registerId = reg.ordinal();
			info("[" + registerId + "]\t" + State.Register.values()[registerId] + " = " + registers[registerId]);
		}
	}

	/**
	 * Comando: dum register. Imprime o conte�do de todos os registradores.
	 * 
	 * @throws IOException	Caso haja falhas no terminal.
	 */
	private void commandDumpRegister() throws IOException  {
		Integer[] registers = new Integer[State.REGISTER_NUMBER];
		this.state.dumpRegister(registers);
		for (int i = 0; i < registers.length; i++) {
			info(String.format("[%02d]: %4s = %08x", i, State.Register.values()[i], registers[i]));
		}		
		info(String.format("        PC = %08x", this.state.getPC()));
	}

	/**
	 * Comando: dump data memory startaddress numberOfIntegers. Imprime uma 
	 * parte do conte�do da mem�ria de dados a partir de um endere�o inicial e 
	 * da quantidade de dados.
	 *  
	 * @param startAddress		O endere�o inicial.
	 * @param numberOfIntegers	A quantidad de dados.
	 * 
	 * @throws IOException	Caso haja falhas no terminal.
	 */
	private void commandDumpDataMemory(String startAddress, String numberOfIntegers) throws IOException {
		Integer start = Integer.decode(startAddress);
		Integer size = Integer.decode(numberOfIntegers);

		size += (4 - (size % 4));

		Integer[] dump = new Integer[size];
		this.state.dumpDataMemory(start, dump);

		String line = "";
		Integer i, k;

		for (i = 0; i < dump.length && dump[i] != null; i++) {
			if (i % 4 == 0) {
				line = String.format("%08x:", start + i);
			}
			for (k = 0; k < 4; k++) {
				line += String.format(" %02x",(dump[i] >> (k*8)) & 0xFF);
			}
			if (i % 4 == 3 || i == dump.length - 1) {
				info(line);
			}
		}
	}

	/**
	 * Comando: dump instruction memory startaddress numberOfIntegers. Imprime
	 * uma parte do conte�do da mem�ria de dados a partir de um endere�o 
	 * inicial e da quantidade de dados.
	 *  
	 * @param startAddress		O endere�o inicial.
	 * @param numberOfIntegers	A quantidad de dados.
	 * 
	 * @throws IOException	Caso haja falhas no terminal.
	 */
	private void commandDumpInstructionMemory(String startAddress, String numberOfIntegers) throws IOException {
		Integer start = Integer.decode(startAddress);
		Integer size = Integer.decode(numberOfIntegers);

		size += (4 - (size % 4));

		Integer[] dump = new Integer[size];
		this.state.dumpInstructionMemory(start, dump);

		String line = "";
		Integer i, k;

		for (i = 0; i < dump.length && dump[i] != null; i++) {
			if (i % 4 == 0) {
				line = String.format("%08x:", start + i);
			}
			for (k = 0; k < 4; k++) {
				line += String.format(" %02x",(dump[i] >> (k*8)) & 0xFF);
			}
			if (i % 4 == 3 || i == dump.length - 1) {
				info(line);
			}
		}
	}
	
}
