/*
 * Universidade Federal Rural de Pernambuco - ufrpe.br
 * Departamento de Estat�stica e Inform�tica - deinfo.ufrpe.br
 * Disciplina de Arquitetura e Organiza��o de Computadores - deinfo.ufrpe.br/14064
 * Professor Andr� Aziz - andreaziz@deinfo.ufrpe.br
 * 
 * Esse programa foi criado com objetivos acad�micos, sendo vedada a sua venda. N�o h�
 * garantias de uso e funcionamento.
 * 
 * Arquivo: TreeCompleter.java
 * Licen�a: GPL v3
 */
package br.ufrpe.deinfo.jline;

import static jline.internal.Preconditions.checkNotNull;

import java.util.Arrays;
import java.util.Collection;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import jline.console.completer.Completer;

/**
 * Classe para permitr o autocompletar do terminal de acordo com os par�metros
 * j� digitados. Essa classe n�o dever ser utilizada pelos alunos.
 * 
 * @author Aziz
 * @since 1.0
 * @version 1.0
 */
public final class TreeCompleter
    implements Completer
{
	public static final String ESCAPE = "";
	private static final Map<Integer, TreeCompleter> clearAllowed = new HashMap<Integer, TreeCompleter>();
	
	private static List<String> currentStrings = new LinkedList<String>();
	
    private final List<String> strings = new LinkedList<String>();
    private Completer completer;
   
    public TreeCompleter(final Completer completer, final Collection<String> strings) {
        checkNotNull(strings);
       
        this.completer = completer;
        this.strings.addAll(strings);
        
        if (!clearAllowed.containsKey(strings.size())) {
        	clearAllowed.put(strings.size(), this);
        }
    }

    public TreeCompleter(final Completer completer, final String... strings) {
        this(completer, Arrays.asList(strings));
    }

    public Collection<String> getStrings() {
        return strings;
    }

    public Integer getLevel() {
    	return this.strings.size();
    }
    
    public int complete(final String buffer, final int cursor, final List<CharSequence> candidates) {
        // buffer could be null
        checkNotNull(candidates);

        if (getLevel() < currentStrings.size() && clearAllowed.get(getLevel()) == this) {
        	currentStrings = currentStrings.subList(0, getLevel());
        }
      
        if (currentStrings.size() != getLevel()) {
        	return -1;
        }
        
        for (Integer i = 0; i < currentStrings.size(); i++) {
        	if (!this.strings.get(i).equals(ESCAPE) && !this.strings.get(i).equals(currentStrings.get(i))) {
        		return -1;
        	} 
        }
        
        Integer ret = this.completer.complete(buffer, cursor, candidates);

        if (candidates.size() == 1) {
        	currentStrings.add(candidates.get(0).toString().trim());
        }
        
        return candidates.isEmpty() ? -1 : ret;
    }
}
