/*
 * Universidade Federal Rural de Pernambuco - ufrpe.br
 * Departamento de Estat�stica e Inform�tica - deinfo.ufrpe.br
 * Disciplina de Arquitetura e Organiza��o de Computadores - deinfo.ufrpe.br/14064
 * Professor Andr� Aziz - andreaziz@deinfo.ufrpe.br
 * 
 * Esse programa foi criado com objetivos acad�micos, sendo vedada a sua venda. N�o h�
 * garantias de uso e funcionamento.
 * 
 * Arquivo: IntegerCompleter.java
 * Licen�a: GPL v3
 */
package br.ufrpe.deinfo.jline;

import static jline.internal.Preconditions.checkNotNull;

import java.util.List;

import jline.console.completer.Completer;

/**
 * Classe para permitr o autocompletar do terminal quando digitados n�meros 
 * inteiros. Essa classe n�o dever ser utilizada pelos alunos.
 * 
 * @author Aziz
 * @since 1.0
 * @version 1.0
 */
public final class IntegerCompleter
    implements Completer
{
    private String label;
	private int radix;

    public IntegerCompleter(String label, Integer radix) {
        checkNotNull(label);
        this.label = label;
        this.radix = radix;
    }
    
    public IntegerCompleter(String label) {
        this(label, 10);
    }

    public int complete(final String buffer, final int cursor, final List<CharSequence> candidates) {
        // buffer could be null
        checkNotNull(candidates);

        if (buffer == null) {
            candidates.add(this.label);
        }
        else {
        	try {
        		Integer.parseInt(buffer.trim(), this.radix);
        		candidates.add(buffer + " ");
        	} catch (NumberFormatException ex) {
        		return -1;
        	}         	
        }

        return 0;
    }
}